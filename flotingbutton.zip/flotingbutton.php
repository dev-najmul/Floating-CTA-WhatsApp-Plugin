<?php
/**
 * Plugin Name: Floating CTA & WhatsApp
 * Plugin URI: https://github.com/dev-najmul/Floating-CTA-WhatsApp-Plugin
 * Description: A lightweight WordPress plugin that adds a floating “Free Consultation” button and a WhatsApp chat icon across your website. Includes full admin controls for colors, position, visibility, and behavior.
 * Version: 1.0.3
 * Author: Farhan raj Najmul
 * Author URI: https://farhanrajnajmul.com
 * License: GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.0
 * Requires PHP: 7.4
 * Text Domain: floating-cta-whatsapp
 * Domain Path: /languages
 */

if ( ! defined('ABSPATH') ) exit;

class NL_Floating_CTA_WhatsApp {
    private $opt_key = 'nl_fcta_wa_options';

    public function __construct() {
        add_action('admin_init',        [$this, 'register_settings']);
        add_action('admin_menu',        [$this, 'add_menu']);
        add_action('wp_head',           [$this, 'print_styles'], 99);
        add_action('wp_footer',         [$this, 'render_cta'], 99);
    }

    /* ---------------- Defaults / Options ---------------- */

    public function default_options() {
        return [
            // Visibility
            'show_button'     => 1,
            'show_whatsapp'   => 1,
            'hide_desktop'    => 0,
            'hide_tablet'     => 0,
            'hide_mobile'     => 0,

            // Button
            'button_text'     => 'Free Consultation',
            'button_url'      => '#',        // default so it shows immediately
            'button_newtab'   => 1,
            'utm'             => '',

            // WhatsApp
            'wa_phone'        => '',         // digits only with country code
            'wa_prefill'      => 'Hi! I’d like a free consultation.',

            // Position
            'side'            => 'right',    // left|right
            'bottom_offset'   => 24,
            'side_offset'     => 24,
            'gap'             => 12,
            'zindex'          => 9999,

            // Style
            'btn_bg'          => '#183a5c',
            'btn_text'        => '#ffffff',
            'btn_radius'      => 28,
            'btn_shadow'      => '0 8px 24px rgba(0,0,0,.18)',
            'icon_bg'         => '#25D366',
            'icon_color'      => '#ffffff',
            'icon_size'       => 52
        ];
    }

    public function get_options() {
        $saved = get_option($this->opt_key, []);
        return wp_parse_args($saved, $this->default_options());
    }

    /* ---------------- Admin ---------------- */

    public function add_menu() {
        add_options_page(
            'Floating CTA & WhatsApp',
            'Floating CTA & WhatsApp',
            'manage_options',
            'floating-cta-whatsapp',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting($this->opt_key, $this->opt_key, [$this, 'sanitize']);

        add_settings_section('nl_fcta_main', 'Floating CTA & WhatsApp', function(){
            echo '<p>Configure the floating WhatsApp icon and CTA button.</p>';
        }, 'floating-cta-whatsapp');

        $fields = [
            ['show_button',   'Show “Free Consultation” button', 'checkbox'],
            ['show_whatsapp', 'Show WhatsApp icon',              'checkbox'],

            ['button_text', 'Button label', 'text'],
            ['button_url',  'Button URL (any link)', 'text'],
            ['button_newtab','Open button in new tab', 'checkbox'],
            ['utm',         'Append UTM (e.g. ?utm_source=cta)', 'text'],

            ['wa_phone',    'WhatsApp phone (digits only, country code)', 'text'],
            ['wa_prefill',  'WhatsApp pre-filled message', 'textarea'],

            ['side',        'Screen side', 'select', ['left'=>'Left','right'=>'Right']],
            ['bottom_offset','Bottom offset (px)', 'number'],
            ['side_offset',  'Side offset (px)',   'number'],
            ['gap',          'Gap between items (px)', 'number'],
            ['zindex',       'Z-index', 'number'],

            ['hide_desktop', 'Hide on Desktop (≥1025px)', 'checkbox'],
            ['hide_tablet',  'Hide on Tablet (641–1024px)', 'checkbox'],
            ['hide_mobile',  'Hide on Mobile (≤640px)', 'checkbox'],

            ['btn_bg',    'Button background', 'color'],
            ['btn_text',  'Button text color', 'color'],
            ['btn_radius','Button border radius (px)', 'number'],
            ['btn_shadow','Button shadow (CSS)', 'text'],

            ['icon_bg',   'WhatsApp icon background', 'color'],
            ['icon_color','WhatsApp icon color', 'color'],
            ['icon_size', 'WhatsApp icon size (px)', 'number'],
        ];

        foreach ($fields as $f) {
            add_settings_field($f[0], $f[1], [$this, 'field_' . $f[2]], 'floating-cta-whatsapp', 'nl_fcta_main', ['key'=>$f[0], 'opts'=>isset($f[3])?$f[3]:[]]);
        }
    }

    private function val($key){ return esc_attr($this->get_options()[$key]); }

    /* Field renderers */
    public function field_checkbox($args){
        $k = $args['key'];
        echo '<label><input type="checkbox" name="'.$this->opt_key.'['.$k.']" value="1" '.checked(1, $this->get_options()[$k], false).'/> Enable</label>';
    }
    public function field_text($args){
        $k = $args['key'];
        echo '<input type="text" class="regular-text" name="'.$this->opt_key.'['.$k.']" value="'.$this->val($k).'">';
    }
    public function field_number($args){
        $k = $args['key'];
        echo '<input type="number" class="small-text" name="'.$this->opt_key.'['.$k.']" value="'.$this->val($k).'">';
    }
    public function field_color($args){
        $k = $args['key'];
        echo '<input type="text" class="regular-text" name="'.$this->opt_key.'['.$k.']" value="'.$this->val($k).'" />';
        echo '<p class="description">Any valid CSS color (e.g. #183a5c, rgb(0,0,0)).</p>';
    }
    public function field_textarea($args){
        $k = $args['key'];
        echo '<textarea class="large-text" rows="3" name="'.$this->opt_key.'['.$k.']">'.esc_textarea($this->get_options()[$k]).'</textarea>';
    }
    public function field_select($args){
        $k = $args['key']; $opts = $args['opts']; $val = $this->get_options()[$k];
        echo '<select name="'.$this->opt_key.'['.$k.']">';
        foreach($opts as $v=>$label){
            echo '<option value="'.esc_attr($v).'" '.selected($v,$val,false).'>'.esc_html($label).'</option>';
        }
        echo '</select>';
    }

    public function sanitize($input){
        $d = $this->default_options();
        $out = [];

        foreach (['show_button','show_whatsapp','hide_desktop','hide_tablet','hide_mobile','button_newtab'] as $k) {
            $out[$k] = isset($input[$k]) ? 1 : 0;
        }

        $out['button_text'] = sanitize_text_field($input['button_text'] ?? $d['button_text']);
        $out['button_url']  = esc_url_raw($input['button_url']  ?? '#'); // keep default visible
        $out['utm']         = sanitize_text_field($input['utm'] ?? '');
        $out['wa_phone']    = preg_replace('/\D+/', '', $input['wa_phone'] ?? '');
        $out['wa_prefill']  = sanitize_textarea_field($input['wa_prefill'] ?? $d['wa_prefill']);

        $out['side']          = in_array(($input['side'] ?? 'right'), ['left','right']) ? $input['side'] : 'right';
        $out['bottom_offset'] = intval($input['bottom_offset'] ?? $d['bottom_offset']);
        $out['side_offset']   = intval($input['side_offset'] ?? $d['side_offset']);
        $out['gap']           = intval($input['gap'] ?? $d['gap']);
        $out['zindex']        = intval($input['zindex'] ?? $d['zindex']);

        foreach(['btn_bg','btn_text','btn_shadow','icon_bg','icon_color'] as $k){
            $out[$k] = sanitize_text_field($input[$k] ?? $d[$k]);
        }
        $out['btn_radius'] = intval($input['btn_radius'] ?? $d['btn_radius']);
        $out['icon_size']  = intval($input['icon_size']  ?? $d['icon_size']);

        return $out;
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Floating CTA & WhatsApp</h1>
            <form method="post" action="options.php">
                <?php
                    settings_fields($this->opt_key);
                    do_settings_sections('floating-cta-whatsapp');
                    submit_button();
                ?>
            </form>
            <p><em>Tip:</em> Enter the WhatsApp phone with country code, digits only (e.g. <strong>971501234567</strong>). Until you set a number, the icon will show but won’t open chat.</p>
        </div>
        <?php
    }

    /* ---------------- Frontend ---------------- */

    public function print_styles() {
        ?>
        <style id="nl-fcta-styles">
          .nl-fcta{
            position:fixed;
            bottom:var(--nl-bottom,24px);
            inset-inline:auto var(--nl-side,24px);
            display:flex;
            flex-direction:column;             /* WhatsApp on top, button below */
            gap:var(--nl-gap,12px);
            z-index:var(--nl-z,9999);
            pointer-events:none
          }
          .nl-fcta.nl-side-left{left:var(--nl-side,24px);right:auto;align-items:flex-start}
          .nl-fcta.nl-side-right{right:var(--nl-side,24px);left:auto;align-items:flex-end}

          .nl-fcta__wa{
            pointer-events:auto;display:grid;place-items:center;
            width:var(--nl-icon-size,52px);height:var(--nl-icon-size,52px);
            border-radius:50%;
            background:var(--nl-icon-bg,#25D366) !important;
            color:var(--nl-icon-color,#fff) !important;
            box-shadow:0 8px 24px rgba(0,0,0,.18)
          }
          .nl-fcta__wa svg{width:60%;height:60%;display:block}

          .nl-fcta__btn{
            pointer-events:auto;display:inline-flex;align-items:center;gap:10px;
            padding:12px 18px;
            background:var(--nl-btn-bg,#183a5c) !important;
            color:var(--nl-btn-txt,#fff) !important;
            border-radius:var(--nl-btn-radius,28px);
            text-decoration:none;font-weight:600;
            box-shadow:var(--nl-btn-shadow,0 8px 24px rgba(0,0,0,.18))
          }
          .nl-fcta__btn:hover{filter:brightness(1.05)}
          .nl-fcta__icon{display:grid;place-items:center;width:20px;height:20px}
          .nl-fcta__icon svg{width:100%;height:100%;fill:currentColor;display:block}

          @media (prefers-reduced-motion:no-preference){
            .nl-fcta__wa,.nl-fcta__btn{transition:transform .2s ease,filter .2s ease}
            .nl-fcta__btn:hover{transform:translateY(-1px)}
          }
          @media (min-width:1025px){.nl-hide-desktop{display:none!important}}
          @media (min-width:641px) and (max-width:1024px){.nl-hide-tablet{display:none!important}}
          @media (max-width:640px){.nl-hide-mobile{display:none!important}}
        </style>
        <?php
    }

    public function render_cta() {
        if ( is_admin() ) return;

        $o = $this->get_options();

        // Device classes + side
        $classes = [];
        if ($o['hide_desktop']) $classes[] = 'nl-hide-desktop';
        if ($o['hide_tablet'])  $classes[] = 'nl-hide-tablet';
        if ($o['hide_mobile'])  $classes[] = 'nl-hide-mobile';
        $classes[] = 'nl-side-' . esc_attr($o['side']);

        // Button URL (+ optional UTM). Always show even if '#'.
        $btn_url = $o['button_url'] ?: '#';
        if ($btn_url && $o['utm'] && $btn_url !== '#') {
            $btn_url .= (strpos($btn_url,'?')!==false ? '&' : '?') . ltrim($o['utm'], '?');
        }

        // WhatsApp URL. If no number yet, keep icon clickable but no-op.
        $wa_href = 'javascript:void(0)';
        $wa_title = 'Set your WhatsApp number in Settings » Floating CTA & WhatsApp';
        if ( $o['wa_phone'] ) {
            $wa_href = 'https://wa.me/' . rawurlencode($o['wa_phone']);
            if ( ! empty($o['wa_prefill']) ) {
                $wa_href .= '?text=' . rawurlencode($o['wa_prefill']);
            }
            $wa_title = 'Chat on WhatsApp';
        }

        // Respect toggles (do not depend on URLs)
        $show_whatsapp = (bool) $o['show_whatsapp'];
        $show_button   = (bool) $o['show_button'];

        // Container-level vars
        $container_style = sprintf(
            '--nl-bottom:%dpx;--nl-side:%dpx;--nl-gap:%dpx;--nl-z:%d;',
            $o['bottom_offset'], $o['side_offset'], $o['gap'], $o['zindex']
        );

        $btn_vars = sprintf(
            '--nl-btn-bg:%s;--nl-btn-txt:%s;--nl-btn-radius:%dpx;--nl-btn-shadow:%s;',
            esc_attr($o['btn_bg']), esc_attr($o['btn_text']), $o['btn_radius'], esc_attr($o['btn_shadow'])
        );
        $wa_vars  = sprintf(
            '--nl-icon-bg:%s;--nl-icon-color:%s;--nl-icon-size:%dpx;',
            esc_attr($o['icon_bg']), esc_attr($o['icon_color']), $o['icon_size']
        );
        ?>
        <div class="nl-fcta <?php echo esc_attr(implode(' ',$classes)); ?>" style="<?php echo esc_attr($container_style); ?>">
            <?php if ($show_whatsapp): ?>
                <a class="nl-fcta__wa"
                   href="<?php echo esc_url($wa_href); ?>" target="_blank" rel="noopener"
                   title="<?php echo esc_attr($wa_title); ?>"
                   aria-label="<?php echo esc_attr($wa_title); ?>"
                   style="<?php echo esc_attr($wa_vars); ?>">
                    <svg viewBox="0 0 32 32" aria-hidden="true">
                        <path fill="currentColor" d="M19.1 17.7c-.3-.2-1.8-.9-2.1-1s-.5-.2-.8.2-.9 1-1.1 1.2-.4.2-.7.1a6.6 6.6 0 0 1-2-1.3 7.2 7.2 0 0 1-1.4-1.8c-.1-.3 0-.4.1-.6l.5-.8.2-.3c.1-.2.1-.4 0-.6s-.6-1.6-.9-2.2-.5-.5-.8-.5h-.7a1.4 1.4 0 0 0-1 .5 4 4 0 0 0-1.2 3c0 1.8 1.3 3.6 1.5 3.9s2.7 4.3 6.6 5.8a7.2 7.2 0 0 0 3 .6 4.1 4.1 0 0 0 2.7-1.2 3.3 3.3 0 0 0 .7-2c0-.6 0-.6-.3-.8zM16.1 3A13 13 0 0 0 3 16.1a12.8 12.8 0 0 0 1.8 6.6L3 29l6.5-1.7a13 13 0 0 0 6.6 1.8A13 13 0 1 0 16.1 3zm0 23.5a10.4 10.4 0 0 1-5.3-1.5l-.4-.2-3.8 1 .9-3.7-.2-.4a10.4 10.4 0 1 1 8.8 4.8z"/>
                    </svg>
                </a>
            <?php endif; ?>

            <?php if ($show_button): ?>
                <a class="nl-fcta__btn"
                   href="<?php echo esc_url($btn_url); ?>"
                   <?php echo ($o['button_newtab'] && $btn_url !== '#') ? 'target="_blank" rel="noopener"' : ''; ?>
                   style="<?php echo esc_attr($btn_vars); ?>">
                    <span class="nl-fcta__icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 3c-4.97 0-9 3.58-9 8 0 1.94.8 3.73 2.15 5.15L3 21l4.02-1.1A10.9 10.9 0 0 0 12 19c4.97 0 9-3.58 9-8s-4.03-8-9-8z"/></svg>
                    </span>
                    <span class="nl-fcta__label"><?php echo esc_html($o['button_text']); ?></span>
                </a>
            <?php endif; ?>
        </div>
        <?php
    }
}

new NL_Floating_CTA_WhatsApp();
